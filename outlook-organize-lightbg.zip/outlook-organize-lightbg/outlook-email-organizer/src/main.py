# --- Email Organizer App Scaffold ---
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from datetime import datetime
import threading
try:
    from outlook.loader import OutlookLoader
    from excel.tracker import ExcelTracker
except ImportError:
    OutlookLoader = object
    ExcelTracker = object

# Data models
class Email:
    def __init__(self, subject, sender, date, body, entry_id, categories=None):
        self.subject = subject
        self.sender = sender
        self.date = date
        self.body = body
        self.entry_id = entry_id
        self.categories = categories or []

class Conversation:
    def __init__(self, emails):
        self.emails = emails  # List[Email]

# Options
DEPARTMENTS = ["ENGINEERING", "NURS", "SALA", "SCARP", "OTHER"]
CATEGORIES = [
    "Canvas Catalogue", "Canvas Support", "Course Access", "Course Creation/Merge/Roll-Over",
    "Equipment Loans", "Handoffs", "ICOLE", "Learning Tech", "Scantron", "SD Requests",
    "Support Sessions", "IT Requests", "Other"
]
ADDRESSED_BY = ["Steven", "Sophie", "LTRs"]
FOLDERS_MAIN = [
    ".Canvas Catalog", ".Canvas Support", ".Course Access", ".Course Creation", ".Cross-listing & Roll-overs",
    ".Equipment Loans", ".Learning Tech", "_IT Requests", ".Handoffs", ".ICOLE", ".Other", ".Scantrons",
    ".SD Requests", ".Support Sessions"
]
FOLDERS_SECONDARY = [
    ".Canvas Workshops", ".SoN Office Hours", "_Auto Replies", "_LT Hub"
]

# Main Application
class EmailOrganizerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Outlook Email Organizer")
        self.root.state('zoomed')  # Open in fullscreen (Windows)
        self.root.configure(bg="#f5f5f5")  # Light gray background

        style = ttk.Style()
        style.theme_use('clam')
        style.configure("Radio.TRadiobutton", background="#f5f5f5", foreground="#222222", font=("Arial", 13))
        style.map("Radio.TRadiobutton",
            background=[('active', "#e0e7ef"), ('selected', '#e0e7ef')],
            foreground=[('active', "#222222"), ('selected', "#0965c0")],
            indicatorcolor=[('selected', "#0965c0"), ('!selected', "#7e7e7e")])
        style.configure("TFrame", background="#f5f5f5")
        style.configure("TLabel", background="#f5f5f5", foreground="#222222", font=("Arial", 14))
        style.configure("TRadiobutton", background="#e0e7ef", foreground="#222222", font=("Arial", 13))
        style.configure("TButton", font=("Arial", 13), padding=6)
        style.configure("TEntry", font=("Arial", 13))
        style.configure("TCheckbutton", background="#f5f5f5", foreground="#222222", font=("Arial", 13))
        style.configure("TSeparator", background="#0965c0")
        
        # Prompt user to select Excel file
        excel_file = self.select_excel_file()
        if not excel_file:
            messagebox.showerror("Error", "No Excel file selected. Application will exit.")
            self.root.quit()
            return
        
        self.loader = OutlookLoader()
        self.tracker = ExcelTracker(excel_file)
        self.conversations = []
        self.current_convo_idx = 0
        self.selected_emails = set()

        # Category to folder mapping
        self.category_to_folder = {
            "Canvas Catalogue": ".Canvas Catalog",
            "Canvas Support": ".Canvas Support",
            "Course Access": ".Course Access",
            "Course Creation/Merge/Roll-Over": ".Cross-listing & Roll-overs",
            "Equipment Loans": ".Equipment Loans",
            "Handoffs": ".Handoffs",
            "ICOLE": ".ICOLE",
            "Learning Tech": ".Learning Tech",
            "Scantron": ".Scantrons",
            "SD Requests": ".SD Requests",
            "Support Sessions": ".Support Sessions",
            "IT Requests": "_IT Requests",
            "Other": ".Other"
        }

        self.setup_ui()
        self.load_conversations()

    def select_excel_file(self):
        """Prompt user to select or create an Excel file for tracking."""
        root = tk.Tk()
        root.withdraw()  # Hide the root window
        
        # Ask user if they want to select existing or create new
        response = messagebox.askyesno(
            "Excel File",
            "Do you want to select an existing Excel file?\n\nYes = Select file\nNo = Create new file"
        )
        
        if response:
            # Select existing file
            file_path = filedialog.askopenfilename(
                title="Select Excel file to track emails",
                filetypes=[("Excel files", "*.xlsx"), ("All files", "*.*")]
            )
            root.destroy()
            return file_path if file_path else None
        else:
            # Create new file
            file_path = filedialog.asksaveasfilename(
                title="Create new Excel file",
                defaultextension=".xlsx",
                filetypes=[("Excel files", "*.xlsx")]
            )
            root.destroy()
            return file_path if file_path else None

    def setup_ui(self):
        # Get screen dimensions for responsive design
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        
        # Calculate responsive padding and sizing
        h_pad_main = max(15, screen_width // 40)  # Horizontal padding
        v_pad_main = max(15, screen_height // 40)  # Vertical padding
        label_font_size = max(12, int(screen_width / 100))
        # Smaller title font for section labels (Department, Category, etc.)
        section_label_size = max(10, int(screen_width / 120))
        title_font_size = max(14, int(screen_width / 90))
        
        # Calculate canvas height - decrease for smaller screens
        if screen_height < 800:
            canvas_height_ratio = 0.35  # Very small screens
        elif screen_height < 1000:
            canvas_height_ratio = 0.40  # Small screens
        else:
            canvas_height_ratio = 0.50  # Normal screens
        
        min_canvas_height = max(250, int(screen_height * canvas_height_ratio))
        
        # Use grid layout on root to keep bottom bar fixed and visible
        self.root.grid_rowconfigure(0, weight=1)  # Main frame expands
        self.root.grid_rowconfigure(1, weight=0)  # Bottom frame stays fixed
        self.root.grid_columnconfigure(0, weight=1)
        
        # Layout: left (options), center (emails), right (options)
        self.main_frame = ttk.Frame(self.root)
        self.main_frame.grid(row=0, column=0, sticky="nsew", padx=0, pady=0)

        self.left_frame = ttk.Frame(self.main_frame)
        self.left_frame.grid(row=0, column=0, sticky="nsw", padx=(h_pad_main, h_pad_main//2), pady=v_pad_main)

        self.center_frame = ttk.Frame(self.main_frame)
        self.center_frame.grid(row=0, column=1, sticky="nsew", padx=h_pad_main//2, pady=v_pad_main)

        self.right_frame = ttk.Frame(self.main_frame)
        self.right_frame.grid(row=0, column=2, sticky="nse", padx=(h_pad_main//2, h_pad_main), pady=v_pad_main)

        self.main_frame.grid_columnconfigure(0, weight=0)
        self.main_frame.grid_columnconfigure(1, weight=2)
        self.main_frame.grid_columnconfigure(2, weight=0)
        self.main_frame.grid_rowconfigure(0, weight=1)

        # Bottom frame - FIXED, won't scroll or disappear
        self.bottom_frame = ttk.Frame(self.root)
        self.bottom_frame.grid(row=1, column=0, sticky="ew", padx=h_pad_main, pady=10)



        # Department (MCQ)

        ttk.Label(self.left_frame, text="Department", font=("Arial", section_label_size, "bold"), foreground="#222222").pack(anchor=tk.W, pady=(0, 8))
        self.department_var = tk.StringVar(value=DEPARTMENTS[0])
        for dept in DEPARTMENTS:
            ttk.Radiobutton(self.left_frame, text=dept, variable=self.department_var, value=dept, style="Radio.TRadiobutton").pack(anchor=tk.W, pady=2)

        ttk.Separator(self.left_frame, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=12)


        # Category (MCQ)
        ttk.Label(self.left_frame, text="Category", font=("Arial", section_label_size, "bold"), foreground="#222222").pack(anchor=tk.W, pady=(0, 8))
        self.category_var = tk.StringVar(value=CATEGORIES[0])
        for cat in CATEGORIES:
            ttk.Radiobutton(self.left_frame, text=cat, variable=self.category_var, value=cat, style="Radio.TRadiobutton", command=self.on_category_change).pack(anchor=tk.W, pady=2)

        ttk.Separator(self.left_frame, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=12)

        # Addressed By (MCQ)
        ttk.Label(self.left_frame, text="Addressed By", font=("Arial", section_label_size, "bold"), foreground="#222222").pack(anchor=tk.W, pady=(0, 8))
        self.addressed_by_var = tk.StringVar(value=ADDRESSED_BY[0])
        for ab in ADDRESSED_BY:
            ttk.Radiobutton(self.left_frame, text=ab, variable=self.addressed_by_var, value=ab, style="Radio.TRadiobutton").pack(anchor=tk.W, pady=2)

        ttk.Separator(self.left_frame, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=12)

        # Folder (MCQ for all folders)
        ttk.Label(self.right_frame, text="Move to Folder", font=("Arial", section_label_size, "bold"), foreground="#222222").pack(anchor=tk.W, pady=(0, 8))
        self.ALL_FOLDERS = FOLDERS_MAIN + FOLDERS_SECONDARY
        self.folder_var = tk.StringVar(value=self.ALL_FOLDERS[0])
        for folder in self.ALL_FOLDERS:
            ttk.Radiobutton(self.right_frame, text=folder, variable=self.folder_var, value=folder, style="Radio.TRadiobutton").pack(anchor=tk.W, pady=2)

        # Set initial folder based on initial category
        self.set_folder_by_category(self.category_var.get())

        # Center: Emails list (do this ONCE only)
        ttk.Label(self.center_frame, text="Emails in Conversation", font=("Arial", title_font_size, "bold"), foreground="#0965c0").pack(anchor=tk.W, pady=(0, 10))
        ttk.Separator(self.center_frame, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=5)
        # Select All checkbox
        self.select_all_var = tk.BooleanVar(value=True)
        select_all_chk = ttk.Checkbutton(self.center_frame, text="Select All", variable=self.select_all_var, command=self.toggle_select_all, style="TCheckbutton")
        select_all_chk.pack(anchor=tk.W, padx=10, pady=(0, 5))
        
        # Scrollable emails frame - height is responsive to screen size
        emails_scroll_container = ttk.Frame(self.center_frame)
        emails_scroll_container.pack(fill=tk.BOTH, expand=True)
        
        emails_canvas = tk.Canvas(emails_scroll_container, bg="#ffffff", highlightthickness=0, height=min_canvas_height)
        scrollbar = ttk.Scrollbar(emails_scroll_container, orient=tk.VERTICAL, command=emails_canvas.yview)
        self.emails_frame = ttk.Frame(emails_canvas)
        self.emails_canvas = emails_canvas  # Store for later use in popup
        
        def _update_scrollregion(e):
            emails_canvas.configure(scrollregion=emails_canvas.bbox("all"))
            # Get content height
            content_height = emails_canvas.bbox("all")[3] - emails_canvas.bbox("all")[1]
            # If content fits in canvas, disable scrolling by setting scroll to beginning
            if content_height <= emails_canvas.winfo_height():
                emails_canvas.yview_moveto(0)
        
        self.emails_frame.bind("<Configure>", _update_scrollregion)
        
        emails_canvas.create_window((0, 0), window=self.emails_frame, anchor="nw")
        emails_canvas.configure(yscrollcommand=scrollbar.set)
        
        emails_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Enable mouse wheel scrolling
        def _on_mousewheel(event):
            emails_canvas.yview_scroll(int(-1*(event.delta/120)), "units")
        self.mousewheel_binding = emails_canvas.bind_all("<MouseWheel>", _on_mousewheel)
        
        self.email_check_vars = []

        # Bottom controls (do this ONCE only)
        # Split into multiple rows if screen is narrow
        if screen_width < 1400:
            # Use multiple rows for narrow screens
            bottom_row1 = ttk.Frame(self.bottom_frame)
            bottom_row1.pack(fill=tk.X, pady=5)
            
            bottom_row2 = ttk.Frame(self.bottom_frame)
            bottom_row2.pack(fill=tk.X, pady=5)
            
            # Row 1: Count and Date
            ttk.Label(bottom_row1, text="Count:").pack(side=tk.LEFT, padx=(0, 5))
            self.count_var = tk.IntVar(value=1)
            ttk.Button(bottom_row1, text="-", width=2, command=self.decrement_count).pack(side=tk.LEFT, padx=1)
            self.count_label = ttk.Label(bottom_row1, text="1", width=3, anchor="center")
            self.count_label.pack(side=tk.LEFT, padx=1)
            ttk.Button(bottom_row1, text="+", width=2, command=self.increment_count).pack(side=tk.LEFT, padx=(1, 15))

            ttk.Label(bottom_row1, text="Date:").pack(side=tk.LEFT)
            self.date_var = tk.StringVar(value=datetime.now().strftime("%Y-%m-%d"))
            self.date_entry = ttk.Entry(bottom_row1, textvariable=self.date_var, width=12)
            self.date_entry.pack(side=tk.LEFT, padx=5)
            
            # Row 2: Comments and Buttons
            ttk.Label(bottom_row2, text="Comments:").pack(side=tk.LEFT)
            self.comments_var = tk.StringVar()
            self.comments_entry = ttk.Entry(bottom_row2, textvariable=self.comments_var, width=30)
            self.comments_entry.pack(side=tk.LEFT, padx=5)

            self.move_btn = ttk.Button(bottom_row2, text="Move", command=self.move_selected)
            self.move_btn.pack(side=tk.RIGHT, padx=5)
            self.skip_btn = ttk.Button(bottom_row2, text="Skip", command=self.skip_conversation)
            self.skip_btn.pack(side=tk.RIGHT, padx=5)
            self.next_btn = ttk.Button(bottom_row2, text="Next", command=self.next_conversation, state=tk.DISABLED)
            self.next_btn.pack(side=tk.RIGHT, padx=5)
        else:
            # Single row for wide screens
            ttk.Label(self.bottom_frame, text="Count:").pack(side=tk.LEFT, padx=(0, 5))
            self.count_var = tk.IntVar(value=1)
            ttk.Button(self.bottom_frame, text="-", width=2, command=self.decrement_count).pack(side=tk.LEFT, padx=1)
            self.count_label = ttk.Label(self.bottom_frame, text="1", width=3, anchor="center")
            self.count_label.pack(side=tk.LEFT, padx=1)
            ttk.Button(self.bottom_frame, text="+", width=2, command=self.increment_count).pack(side=tk.LEFT, padx=(1, 15))

            ttk.Label(self.bottom_frame, text="Date:").pack(side=tk.LEFT)
            self.date_var = tk.StringVar(value=datetime.now().strftime("%Y-%m-%d"))
            self.date_entry = ttk.Entry(self.bottom_frame, textvariable=self.date_var, width=12)
            self.date_entry.pack(side=tk.LEFT, padx=5)

            ttk.Label(self.bottom_frame, text="Comments:").pack(side=tk.LEFT)
            self.comments_var = tk.StringVar()
            self.comments_entry = ttk.Entry(self.bottom_frame, textvariable=self.comments_var, width=30)
            self.comments_entry.pack(side=tk.LEFT, padx=5)

            self.move_btn = ttk.Button(self.bottom_frame, text="Move", command=self.move_selected)
            self.move_btn.pack(side=tk.RIGHT, padx=5)
            self.skip_btn = ttk.Button(self.bottom_frame, text="Skip", command=self.skip_conversation)
            self.skip_btn.pack(side=tk.RIGHT, padx=5)
            self.next_btn = ttk.Button(self.bottom_frame, text="Next", command=self.next_conversation, state=tk.DISABLED)
            self.next_btn.pack(side=tk.RIGHT, padx=5)
    def on_category_change(self):
        # When category changes, auto-select mapped folder if mapping exists
        cat = self.category_var.get()
        self.set_folder_by_category(cat)

    def set_folder_by_category(self, category):
        folder = self.category_to_folder.get(category)
        if folder and folder in self.ALL_FOLDERS:
            self.folder_var.set(folder)
        # else do not change folder selection

    def load_conversations(self):
        # Load conversations from Outlook (in a thread to avoid UI freeze)
        def loader():
            try:
                # Load from the Inbox in the "APSC CIS Learning" mailbox
                self.conversations = self.loader.load_conversations("APSC CIS Learning", "Inbox")
                # Reverse so oldest conversations appear first
                self.conversations = list(reversed(self.conversations))
            except Exception as e:
                import traceback
                print(f"[ERROR] Failed to load conversations:")
                traceback.print_exc()
                self.conversations = []
            self.current_convo_idx = 0
            self.display_conversation()
        threading.Thread(target=loader).start()

    def display_conversation(self):
        # Clear previous
        for widget in self.emails_frame.winfo_children():
            widget.destroy()
        self.email_check_vars.clear()
        if not self.conversations or self.current_convo_idx >= len(self.conversations):
            ttk.Label(self.emails_frame, text="No more conversations.").pack()
            self.next_btn.config(state=tk.DISABLED)
            print("[DEBUG] No conversations loaded.")
            return
        convo = self.conversations[self.current_convo_idx]
        if not convo.emails:
            ttk.Label(self.emails_frame, text="No emails in this conversation.").pack()
            print("[DEBUG] Conversation loaded but no emails found.")
            return
        print(f"[DEBUG] Displaying {len(convo.emails)} emails in conversation.")
        
        # Update date field to first email's date (format as mm/dd/yy)
        if convo.emails:
            first_email = convo.emails[0]
            date_only = first_email.date.split()[0] if ' ' in first_email.date else first_email.date
            # Parse and reformat date to mm/dd/yy
            try:
                from datetime import datetime
                parsed_date = datetime.strptime(date_only, "%Y-%m-%d")
                formatted_date = parsed_date.strftime("%m/%d/%y")
                self.date_var.set(formatted_date)
            except:
                self.date_var.set(date_only)
        
        # Show latest email first (don't reverse - keep original order)
        emails_to_display = convo.emails
        
        for idx, email in enumerate(emails_to_display):
            var = tk.BooleanVar(value=True)
            self.email_check_vars.append(var)
            row = ttk.Frame(self.emails_frame, style="TFrame")
            row.pack(fill=tk.X, pady=1, padx=0)
            
            # Checkbox with command to update select all button
            chk = ttk.Checkbutton(row, variable=var, style="TCheckbutton", command=self.on_email_deselect)
            chk.pack(side=tk.LEFT, padx=8)
            
            # Email info (header) with completion flag
            flag_indicator = "✓ " if var.get() else "  "
            info = f"{flag_indicator}{email.date} | {email.sender} | {email.subject}"
            label = ttk.Label(row, text=info, wraplength=900, justify=tk.LEFT, font=("Arial", 14), foreground="#222222", background="#ffffff")
            label.pack(side=tk.LEFT, padx=10)
            
            # Update flag when checkbox is toggled
            def update_label(email_label=label, check_var=var, original_info=f"{email.date} | {email.sender} | {email.subject}"):
                flag = "✓ " if check_var.get() else "  "
                email_label.config(text=f"{flag}{original_info}")
            
            var.trace('w', lambda *args, func=update_label: func())
            
            # Display categories on separate line with bullet dots
            if email.categories:
                categories_display = " • ".join(email.categories)
                categories_text = f"Categories: {categories_display}"
                categories_label = ttk.Label(self.emails_frame, text=categories_text, wraplength=900, justify=tk.LEFT, 
                                            font=("Arial", 12), foreground="#0965c0", background="#ffffff")
                categories_label.pack(anchor=tk.W, padx=30, pady=(2, 0))
            
            # Compress newlines in body text for preview
            body_preview = email.body.replace('\r\n\r\n', '\n').replace('\n\n', '\n')[:150]
            preview_label = ttk.Label(self.emails_frame, text=body_preview, wraplength=900, justify=tk.LEFT, 
                                     font=("Arial", 9), foreground="#555555", background="#ffffff")
            preview_label.pack(anchor=tk.W, padx=30, pady=0)
            
            # Show Body button - opens popup
            def show_body_popup(subject=email.subject, body_text=email.body):
                """Create a popup window to show email body"""
                popup = tk.Toplevel(self.root)
                popup.title(f"Email Body: {subject}")
                popup.geometry("900x600")
                popup.configure(bg="#ffffff")
                popup.resizable(False, False)  # Disable resizing
                popup.attributes('-topmost', True)  # Always on top
                popup.grab_set()  # Make modal - block interaction with main window
                
                # Header
                ttk.Label(popup, text=subject, font=("Arial", 14, "bold"), foreground="#0965c0").pack(anchor=tk.W, padx=10, pady=10)
                ttk.Separator(popup, orient=tk.HORIZONTAL).pack(fill=tk.X, padx=10)
                
                # Scrollable text area
                text_frame = ttk.Frame(popup)
                text_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
                
                canvas = tk.Canvas(text_frame, bg="#ffffff", highlightthickness=0)
                scrollbar = ttk.Scrollbar(text_frame, orient=tk.VERTICAL, command=canvas.yview)
                scrollable_frame = ttk.Frame(canvas)
                
                scrollable_frame.bind(
                    "<Configure>",
                    lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
                )
                
                canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
                canvas.configure(yscrollcommand=scrollbar.set)
                
                # Compress newlines and display body
                compressed_body = body_text.replace('\r\n\r\n', '\n').replace('\n\n', '\n')
                body_label = ttk.Label(scrollable_frame, text=compressed_body, 
                                      wraplength=850, justify=tk.LEFT, font=("Arial", 10), 
                                      foreground="#222222", background="#ffffff")
                body_label.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
                
                canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
                scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
                
                # Enable mouse wheel scrolling in popup only
                def _on_popup_mousewheel(event):
                    try:
                        if popup.winfo_exists():
                            canvas.yview_scroll(int(-1*(event.delta/120)), "units")
                            return "break"  # Stop event propagation
                    except:
                        pass
                
                def on_popup_close():
                    try:
                        # Re-enable main window scrolling
                        popup.unbind("<MouseWheel>")
                        self.emails_canvas.bind_all("<MouseWheel>", lambda e: self.emails_canvas.yview_scroll(int(-1*(e.delta/120)), "units"))
                    except:
                        pass
                    popup.destroy()
                
                # Disable main window scrolling while popup is open
                try:
                    self.emails_canvas.unbind_all("<MouseWheel>")
                except:
                    pass
                
                popup.protocol("WM_DELETE_WINDOW", on_popup_close)
                popup.bind("<MouseWheel>", _on_popup_mousewheel)
                
                # Close button
                ttk.Button(popup, text="Close", command=on_popup_close).pack(pady=10)
            
            show_btn = ttk.Button(self.emails_frame, text="[+] Show Body", command=show_body_popup)
            show_btn.pack(anchor=tk.W, padx=30, pady=2)
            
            if idx < len(emails_to_display) - 1:
                ttk.Separator(self.emails_frame, orient=tk.HORIZONTAL).pack(fill=tk.X, padx=10, pady=0)

    def on_email_deselect(self):
        """Called when any email checkbox is toggled to update select all button."""
        all_selected = all(var.get() for var in self.email_check_vars)
        if all_selected:
            self.select_all_var.set(True)
        else:
            self.select_all_var.set(False)

    def increment_count(self):
        """Increment the count by 1."""
        self.count_var.set(self.count_var.get() + 1)
        self.count_label.config(text=str(self.count_var.get()))

    def decrement_count(self):
        """Decrement the count by 1 (minimum 0)."""
        current = self.count_var.get()
        if current > 0:
            self.count_var.set(current - 1)
            self.count_label.config(text=str(self.count_var.get()))

    def toggle_select_all(self):
        value = self.select_all_var.get()
        for var in self.email_check_vars:
            var.set(value)

    def move_selected(self):
        if not self.conversations or self.current_convo_idx >= len(self.conversations):
            messagebox.showwarning("No Conversation", "No conversation loaded to move.")
            return
        
        convo = self.conversations[self.current_convo_idx]
        selected = [email for email, var in zip(convo.emails, self.email_check_vars) if var.get()]
        if not selected:
            messagebox.showwarning("No Selection", "Select at least one email to move.")
            return
        
        # Move emails in Outlook
        move_success = self.loader.move_emails(selected, self.folder_var.get())
        
        if not move_success:
            # Move failed - don't log to Excel, show error, and go to next
            messagebox.showerror("Move Failed", 
                f"Failed to move emails to '{self.folder_var.get()}'. "
                "No entry logged to Excel. Moving to next conversation...")
            self.next_conversation()
            return
        
        # Move was successful - log to Excel
        self.tracker.log_entry(
            date=self.date_var.get(),
            department=self.department_var.get(),
            category=self.category_var.get(),
            addressed_by=self.addressed_by_var.get(),
            count=self.count_var.get(),
            comments=self.comments_var.get()
        )
        
        # Remove moved emails from display
        for idx, var in reversed(list(enumerate(self.email_check_vars))):
            if var.get():
                del convo.emails[idx]
                del self.email_check_vars[idx]
        self.display_conversation()
        # Scroll to top
        self.emails_canvas.yview_moveto(0)
        # Enable next if all emails are moved
        if not convo.emails:
            self.next_btn.config(state=tk.NORMAL)

    def skip_conversation(self):
        self.next_conversation()

    def next_conversation(self):
        self.current_convo_idx += 1
        self.next_btn.config(state=tk.DISABLED)
        self.count_var.set(1)
        self.count_label.config(text="1")
        self.comments_var.set("")
        self.display_conversation()
        # Scroll to top
        self.emails_canvas.yview_moveto(0)

def debug_list_folders():
    """List all available Outlook folders and subfolders to help identify the correct folder name."""
    try:
        loader = OutlookLoader()
        outlook = loader.outlook
        print("\n=== Available Outlook Mailboxes/Folders ===")
        for i in range(outlook.Folders.Count):
            mailbox = outlook.Folders.Item(i + 1)
            print(f"\nMailbox: {mailbox.Name}")
            for j in range(min(mailbox.Folders.Count, 20)):  # Limit to first 20
                folder = mailbox.Folders.Item(j + 1)
                print(f"  - {folder.Name}")
        
        # Also list Inbox subfolders for APSC CIS Learning
        print("\n=== Subfolders in APSC CIS Learning / Inbox ===")
        subfolders = loader.list_subfolders('APSC CIS Learning', "Inbox")
        for sf in subfolders:
            print(f"  - {sf}")
    except Exception as e:
        print(f"Error listing folders: {e}")

if __name__ == "__main__":
    try:
        # Uncomment the line below to debug and list all available folders
        # debug_list_folders()
        root = tk.Tk()
        app = EmailOrganizerApp(root)
        root.mainloop()
    except Exception as e:
        import traceback
        print("\n--- Application Error ---")
        traceback.print_exc()