def validate_email(email):
    import re
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None

def format_date(date):
    from datetime import datetime
    return date.strftime('%Y-%m-%d %H:%M:%S')

def sanitize_input(user_input):
    return user_input.strip()