import pandas as pd
import os
from pathlib import Path

class ExcelTracker:
    def __init__(self, file_name=None):
        # Use absolute path in the workspace root
        if file_name is None:
            # Get the path relative to this script
            current_dir = Path(__file__).parent.parent.parent
            file_name = current_dir / 'email_tracking.xlsx'
        
        self.file_name = str(file_name)
        print(f"[DEBUG] Excel file path: {self.file_name}")
        self.create_excel_file()

    def create_excel_file(self):
        columns = ['Date', 'Department/Team', 'Request Type', 'Addressed By', 'Count', 'Extra Comments']
        
        # Only create if file doesn't exist
        if not os.path.exists(self.file_name):
            try:
                df = pd.DataFrame(columns=columns)
                df.to_excel(self.file_name, index=False)
                print(f"[DEBUG] Created new Excel file: {self.file_name}")
            except Exception as e:
                print(f"[ERROR] Failed to create Excel file: {e}")
        else:
            print(f"[DEBUG] Excel file already exists: {self.file_name}")

    def log_email_details(self, date, department, category, addressed_by, count, comments):
        try:
            # Read existing file
            if os.path.exists(self.file_name):
                df = pd.read_excel(self.file_name)
            else:
                # Create empty dataframe if file doesn't exist
                columns = ['Date', 'Department/Team', 'Request Type', 'Addressed By', 'Count', 'Extra Comments']
                df = pd.DataFrame(columns=columns)
            
            new_entry = {
                'Date': date,
                'Department/Team': department,
                'Request Type': category,
                'Addressed By': addressed_by,
                'Count': count,
                'Extra Comments': comments
            }
            
            df = pd.concat([df, pd.DataFrame([new_entry])], ignore_index=True)
            df.to_excel(self.file_name, index=False)
            print(f"[DEBUG] Logged entry to Excel: {new_entry}")
        except Exception as e:
            print(f"[ERROR] Failed to log entry: {e}")

    def log_entry(self, date, department, category, addressed_by, count, comments):
        self.log_email_details(date, department, category, addressed_by, count, comments)