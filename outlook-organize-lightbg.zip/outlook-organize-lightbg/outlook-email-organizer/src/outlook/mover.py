class EmailMover:
    def __init__(self, outlook_connection, excel_tracker):
        self.outlook_connection = outlook_connection
        self.excel_tracker = excel_tracker

    def move_email(self, email, folder_name):
        # Logic to move the email to the specified folder in Outlook
        self.outlook_connection.move_to_folder(email, folder_name)
        self.log_email_details(email, folder_name)

    def log_email_details(self, email, folder_name):
        # Extract relevant details from the email
        details = {
            'Date': email.date,
            'Department': email.department,
            'Category': email.category,
            'Addressed By': email.addressed_by,
            'Count': 1,  # Assuming one email is moved at a time
            'Comments': f'Moved to {folder_name}'
        }
        self.excel_tracker.update_sheet(details)

    def clear_display(self):
        # Logic to clear the display after moving emails
        pass  # Implementation depends on the UI framework used