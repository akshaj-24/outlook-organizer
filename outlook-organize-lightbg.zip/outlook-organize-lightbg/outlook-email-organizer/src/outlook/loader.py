
import win32com.client
import pythoncom
from datetime import datetime

class OutlookLoader:
    def __init__(self):
        pass  # Don't initialize here, do it per-method to keep connection fresh

    def load_conversations(self, mailbox_name, folder_name="Inbox"):
        """
        Load conversations from a specific mailbox and folder.
        Returns a list of Conversation objects.
        
        Args:
            mailbox_name: Name of the mailbox (e.g., "APSC CIS Learning")
            folder_name: Name of the folder within the mailbox (default: "Inbox")
        """
        # Initialize COM for this thread
        pythoncom.CoInitialize()
        try:
            # Create fresh Outlook connection each time
            outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")
            print(f"[DEBUG] Connected to Outlook")
            
            # Find the mailbox
            mailbox = None
            for i in range(outlook.Folders.Count):
                folder = outlook.Folders.Item(i + 1)
                if folder.Name == mailbox_name:
                    mailbox = folder
                    print(f"[DEBUG] Found mailbox: {mailbox_name}")
                    break
            
            if mailbox is None:
                raise Exception(f"Mailbox '{mailbox_name}' not found.")
            
            # Get the folder
            inbox = mailbox.Folders.Item(folder_name)
            print(f"[DEBUG] Found folder: {folder_name}")
            
            messages = inbox.Items
            messages.Sort("[ReceivedTime]", True)
            print(f"[DEBUG] Total messages: {messages.Count}")
            
            # Group emails by conversation ID
            conversation_dict = {}
            
            # Use direct iteration instead of GetFirst/GetNext
            for i in range(1, messages.Count + 1):
                try:
                    msg = messages.Item(i)
                    conv_id = msg.ConversationID
                    if conv_id not in conversation_dict:
                        conversation_dict[conv_id] = []
                    conversation_dict[conv_id].append(msg)
                except Exception as e:
                    print(f"[DEBUG] Error processing message {i}: {e}")
                    pass
            
            print(f"[DEBUG] Processed {messages.Count} messages into {len(conversation_dict)} conversations")
            
            # Convert to Email/Conversation objects
            from main import Email, Conversation
            result = []
            for conv_id, msgs in conversation_dict.items():
                emails = []
                for msg in msgs:
                    try:
                        # Extract categories from Outlook email
                        categories = []
                        if hasattr(msg, 'Categories') and msg.Categories:
                            try:
                                categories = [str(cat) for cat in msg.Categories.split(", ")] if isinstance(msg.Categories, str) else []
                            except:
                                pass
                        
                        emails.append(Email(
                            subject=msg.Subject,
                            sender=msg.SenderName,
                            date=msg.ReceivedTime.strftime("%Y-%m-%d %H:%M"),
                            body=getattr(msg, 'Body', ''),
                            entry_id=msg.EntryID,
                            categories=categories
                        ))
                        
                    except Exception:
                        continue
                if emails:
                    result.append(Conversation(emails))
            
            print(f"[DEBUG] Converted to {len(result)} Conversation objects")
            return result
        finally:
            pythoncom.CoUninitialize()

    def move_emails(self, emails, folder_name, mailbox_name="APSC CIS Learning"):
        """Move emails to a specified subfolder in the Inbox.
        
        Args:
            emails: List of Email objects to move
            folder_name: Name of the destination folder
            mailbox_name: Name of the mailbox
            
        Returns:
            bool: True if all emails moved successfully, False otherwise
        """
        if not emails:
            return True
        
        # Initialize COM for this thread
        pythoncom.CoInitialize()
        try:
            # Create fresh Outlook connection
            outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")
            
            # Find the mailbox
            mailbox = None
            for i in range(outlook.Folders.Count):
                folder = outlook.Folders.Item(i + 1)
                if folder.Name == mailbox_name:
                    mailbox = folder
                    break
            
            if mailbox is None:
                print(f"Mailbox '{mailbox_name}' not found.")
                return False
            
            # Get the inbox
            inbox = mailbox.Folders.Item("Inbox")
            
            # Find the destination folder - check both inbox subfolders and mailbox root level
            dest_folder = None
            
            # First try to find in inbox subfolders
            for i in range(1, inbox.Folders.Count + 1):
                folder = inbox.Folders.Item(i)
                if folder.Name == folder_name:
                    dest_folder = folder
                    break
            
            # If not found in inbox, try mailbox root level
            if dest_folder is None:
                for i in range(1, mailbox.Folders.Count + 1):
                    folder = mailbox.Folders.Item(i)
                    if folder.Name == folder_name:
                        dest_folder = folder
                        break
            
            if dest_folder is None:
                print(f"Destination folder '{folder_name}' not found in inbox or mailbox.")
                return False
            
            # Move all emails
            all_success = True
            for email in emails:
                try:
                    item = outlook.GetItemFromID(email.entry_id)
                    item.Move(dest_folder)
                    print(f"Successfully moved email: {email.subject}")
                except Exception as e:
                    print(f"Failed to move email '{email.subject}': {e}")
                    all_success = False
            
            return all_success
        finally:
            pythoncom.CoUninitialize()

    def list_subfolders(self, mailbox_name, folder_name="Inbox"):
        """List all subfolders in a given folder (for debugging)."""
        # Initialize COM for this thread
        pythoncom.CoInitialize()
        try:
            # Create fresh Outlook connection
            outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")
            
            # Find the mailbox
            mailbox = None
            for i in range(outlook.Folders.Count):
                folder = outlook.Folders.Item(i + 1)
                if folder.Name == mailbox_name:
                    mailbox = folder
                    break
            
            if mailbox is None:
                print(f"Mailbox '{mailbox_name}' not found.")
                return []
            
            # Get the folder
            try:
                folder = mailbox.Folders.Item(folder_name)
            except Exception:
                print(f"Folder '{folder_name}' not found in '{mailbox_name}'")
                return []
            
            # List subfolders
            subfolders = []
            for i in range(folder.Folders.Count):
                sub = folder.Folders.Item(i + 1)
                subfolders.append(sub.Name)
            
            return subfolders
        finally:
            pythoncom.CoUninitialize()