class EmailCategorizer:
    def __init__(self):
        self.categories = {
            'Work': ['Project A', 'Project B'],
            'Personal': ['Family', 'Friends'],
            'Spam': ['Promotions', 'Advertisements']
        }

    def display_categories(self):
        print("Available Categories:")
        for category in self.categories:
            print(f"- {category}")

    def categorize_email(self, email_subject):
        for category, keywords in self.categories.items():
            if any(keyword in email_subject for keyword in keywords):
                return category
        return 'Uncategorized'