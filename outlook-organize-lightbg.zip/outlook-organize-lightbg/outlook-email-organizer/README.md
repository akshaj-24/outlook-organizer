# Outlook Email Organizer

## Overview
The Outlook Email Organizer is a Python application designed to streamline the management of emails in Microsoft Outlook. It allows users to load conversations, categorize emails, and move them into designated subfolders while tracking the details in an Excel sheet.

## Features
- Load conversations from Outlook.
- Categorize emails based on user-selected options.
- Move emails into specified subfolders.
- Log email details into an Excel sheet for tracking.

## Project Structure
```
outlook-email-organizer
├── src
│   ├── main.py               # Entry point of the application
│   ├── outlook
│   │   ├── loader.py         # Loads emails from Outlook
│   │   ├── categorizer.py     # Categorizes emails
│   │   └── mover.py          # Moves emails to subfolders
│   ├── excel
│   │   └── tracker.py        # Manages Excel logging
│   └── utils
│       └── helpers.py        # Utility functions
├── requirements.txt          # Project dependencies
└── README.md                 # Project documentation
```

## Installation
1. Clone the repository:
   ```
   git clone <repository-url>
   ```
2. Navigate to the project directory:
   ```
   cd outlook-email-organizer
   ```
3. Install the required dependencies:
   ```
   pip install -r requirements.txt
   ```

## Usage
1. Run the application:
   ```
   python src/main.py
   ```
2. Follow the on-screen instructions to load conversations, categorize, and move emails.

## Dependencies
The project requires the following Python packages:
- `pywin32` for Outlook integration
- `openpyxl` for Excel file manipulation
- Any other necessary packages listed in `requirements.txt`.

## Contributing
Contributions are welcome! Please submit a pull request or open an issue for any enhancements or bug fixes.

## License
This project is licensed under the MIT License. See the LICENSE file for details.